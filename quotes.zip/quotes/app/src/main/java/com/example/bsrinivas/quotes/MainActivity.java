package com.example.bsrinivas.quotes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button quotebutton;
    private TextView qoutetextview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qoutetextview=findViewById(R.id.qoutetext);
        quotebutton=findViewById(R.id.qoutebuttont);
        quotebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                quotesserver quotesserver= new quotesserver();


                qoutetextview.setText(quotesserver.getRandomquote());
            }
        });
    }
}
